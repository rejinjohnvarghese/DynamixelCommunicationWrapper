Please fill out the questionaire to give you the best support service.  

- Which DYNAMIXEL is it?

  [　-　]  ( ex: MX-64AT , XM430-350R , PRO H54-100-S500-R , ...)

- Which CONTROLLER is it?

  [　　　] ( ex: OpenCM , OpenCR , Arduino Uno , PC via USB2Dynamixel , ... )

- Which VERSION of DynamixelSDK is it?

  ([NOTE] DynamixelSDK Q&A is not available anymore if it is older than ver. 3.0.0, but feedback us)

  [　　　] ( ex: 3.4.2 , dxl_sdk_win32_v2_02.zip , ... )

- Any PICTURES or VIDEOS?

  ![](　Link the PICTURES or VIDEOS here, if necessary　)

- Any SOURCE SAMPLES?

  [](　Link the SOURCE SAMPLES here, if necessary　)
